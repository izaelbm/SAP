#Autor: Izael Magalhaes
#Email: izaelbm@gmail.com
#Engenharia de Serviços Positivo Tecnologia
#Compilação 02/09/2021
#Descricao:Script para ajuste de dados de Parceiro - Script SAP .vbs

#importando bibliotecas
import os
import re
from datetime import datetime

#coletando o local de execução do arquivo
dir = os.path.dirname(os.path.realpath(__file__))
#setando o local de execução do arquivo
os.chdir(dir) #coletando dados do diretorio atual

#validando se o arquivo de dados esta criado
try:
    script_file = open("script.vbs", "r+")  #verifica se o arquivo ja existe
    script_file.close()
    
    os.unlink("script.vbs") #remove arquivo ja existente
    
    script_file = open("script.vbs", "w+") #cria o novo arquivo
    script_file.close()
except FileNotFoundError:
    script_file = open("script.vbs", "w+") #cria o novo arquivo caso nao exista 
    script_file.close()
    
#criando o cabeçalho do script

#abrindo os arquivos
header_file = open("header_script.txt","r+")
script_file = open("script.vbs","a")

#escrevendo no arquivo de script
for header_line in header_file:
    script_file.write(header_line)

#criando uma quebra de linha    
script_file.write('\n')

#fechando os arquivos
script_file.close()
header_file.close()

#abrindo o arquivo data/script
data_file = open("data.txt","r+")
script_file = open("script.vbs","a")

#percorrendo as linhas do arquivo data
for data_line in data_file:
    texto = data_line.split(";") #separando as linhas 
    serial = texto[0] #coletando o serial
    parceiro = texto[1] #coletando o parceiro

    #montando o script
    
    script_file.write('session.findById("wnd[0]").maximize')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/usr/txtSERNR-LOW").text = "' + str.strip(serial) + '"')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/usr/txtSERNR-LOW").setFocus')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/usr/txtSERNR-LOW").caretPosition = 12')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]").sendVKey 8')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/usr/tabsTABSTRIP/tabpT\05").select')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/usr/tabsTABSTRIP/tabpT\05/ssubSUB_DATA:SAPLITO0:0102/subSUB_0102A:SAPLITO0:1092/subSUB_1092A:SAPLIPAR:0201/tblSAPLIPARTCTRL_0200/ctxtIHPA-PARNR[1,0]").text = "' + str.strip(parceiro) + '"')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/usr/tabsTABSTRIP/tabpT\05/ssubSUB_DATA:SAPLITO0:0102/subSUB_0102A:SAPLITO0:1092/subSUB_1092A:SAPLIPAR:0201/tblSAPLIPARTCTRL_0200/ctxtIHPA-PARNR[1,0]").setFocus')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/usr/tabsTABSTRIP/tabpT\05/ssubSUB_DATA:SAPLITO0:0102/subSUB_0102A:SAPLITO0:1092/subSUB_1092A:SAPLIPAR:0201/tblSAPLIPARTCTRL_0200/ctxtIHPA-PARNR[1,0]").caretPosition = 10')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]").sendVKey 0')
    script_file.write('\n')
    script_file.write('session.findById("wnd[0]/tbar[0]/btn[11]").press')

#fechando os arquivos
script_file.close()
data_file.close()