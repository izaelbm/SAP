#Autor: Izael Magalhaes
#Email: izaelbm@gmail.com
#Engenharia de Serviços Positivo Tecnologia
#Compilação 02/09/2021
#versão 2.0
#Descricao:Script para ajuste de dados de Parceiro - Script SAP .vbs

#importando bibliotecas
import os
import re
from datetime import datetime

#coletando o local de execução do arquivo
dir = os.path.dirname(os.path.realpath(__file__))
#setando o local de execução do arquivo
os.chdir(dir) #coletando dados do diretorio atual

#validando se o arquivo de dados esta criado
try:
    script_file = open("script.vbs", "r+")  #verifica se o arquivo ja existe
    script_file.close()
    
    os.unlink("script.vbs") #remove arquivo ja existente
    
    script_file = open("script.vbs", "w+") #cria o novo arquivo
    script_file.close()
except FileNotFoundError:
    script_file = open("script.vbs", "w+") #cria o novo arquivo caso nao exista 
    script_file.close()
    
#criando o cabeçalho do script

#abrindo os arquivos
header_file = open("config/header_script.txt","r+")
script_file = open("script.vbs","a")

#escrevendo no arquivo de script
script_file.write(header_file.read())   
    
#criando uma quebra de linha    
#script_file.write('\n')

#fechando os arquivos
script_file.close()
header_file.close()

#abrindo o arquivo data/script/chave
data_file = open("script_sap/data.txt","r+")

for data_line in data_file:#percorrendo as linhas do arquivo data
    temp_file = open("temp/temp_script.txt","a")
    sap_file = open("script_sap/script_sap.txt","r+")    
    chave_file = open("script_sap/chave.txt","r+")
    script_file = open("script.vbs","a")
    
    #separando a string data
    split_data = data_line.split(";")
    
    #separando a string chave
    chave = chave_file.read()
    split_chave = chave.split(";")
        
    for ArraySap in sap_file:          
        
        temp_text = "vazio"
        cont = 0
        for ArrayChave in split_chave:
                        
            if ArrayChave in ArraySap:
                temp_text = ArraySap.replace(str.strip(ArrayChave),str.strip(split_data[cont])) 
                
            else:
                temp_text = temp_text
                
            cont = cont + 1    
        
        if temp_text == "vazio":
            temp_text = ArraySap
        else:
            temp_text = temp_text
           
            
        temp_file.write(temp_text)       
        
    temp_file.close()
    sap_file.close()
    chave_file.close()    
    temp_file_read = open("temp/temp_script.txt","r")
    script_file.write(temp_file_read.read())
    script_file.close()
    with open('temp/temp_script.txt','w'): pass
    