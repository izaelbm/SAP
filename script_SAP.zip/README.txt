#Autor: Izael Magalhaes
#Email: izaelbm@gmail.com
#Engenharia de Serviços Positivo Tecnologia
#Compilação 02/09/2021
#Descricao:Script para ajuste de dados de Parceiro - Script SAP .vbsserial;codigodoparceiro

*Este script utiliza a transação IE06, desta forma certifique-se que tem acesso a ela.
*Este scipt utiliza o interpretador do python, desta forma certifique-se que o tenha instalado

*Modo de uso

	- abra o arquivo data.txt e adicione os dados de serial e codigo do parceiro separando os dados com ";" 
	conforme modelo abaixo, lembrando que cada serial deve estar em uma unica linha

		serial;codigodoparceiro
		serial;codigodoparceiro

	- execute o arquivo start.py e aguarde o arquivo script.vbs ser criado
	- execute o arquivo script.vbs na tela inicial da transação IE06

*Em casos de duvida entre em contato ibmagalhaes@positivo.com.br